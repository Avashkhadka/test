<?php
header("Content-Type: application/json");

include "../../connect.php";

$Grade = $_POST['Grade'];
$Exam = $_POST['Exam'];
$Section = $_POST['Section'];
$Subject = $_POST['Subject'];

if($Grade === "Default"){
    echo json_encode(["Error" => "Default Grade"]);
    exit();
}
if($Exam == ""){
    echo json_encode(["Error" => "Empty Exam"]);

    exit();
}
if($Subject === "Default"){
    echo json_encode(["Error" => "Default Subject"]);
    exit();
}
if($Section === "Default"){
    $query = "SELECT Marks.Std_Id, Marks.Theory_Marks,Marks.Practical_Marks
                FROM Marks
                JOIN Students ON Students.Std_Id = Marks.Std_Id
                JOIN Class ON Class.Class_Id = Students.Class_Id
                JOIN Exams ON Exams.Exam_Id = Marks.Exam_Id
                JOIn Subjects ON Subjects.Sub_Id = Marks.Sub_Id
                WHERE Class.Grade = '$Grade' AND Subjects.Sub_Name ='$Subject' AND Exams.Exam_Name = '$Exam'
                ORDER BY Marks.Std_Id ";
}else{
    $query = "SELECT Marks.Std_Id, Marks.Theory_Marks, Marks.Practical_Marks
            FROM Marks
            JOIN Students ON Students.Std_Id = Marks.Std_Id
            JOIN Class ON Class.Class_Id = Students.Class_Id
            JOIN Exams ON Exams.Exam_Id = Marks.Exam_Id
            JOIn Subjects ON Subjects.Sub_Id = Marks.Sub_Id
            WHERE Class.Grade = '$Grade' AND Class.Section ='$Section' AND Subjects.Sub_Name ='$Subject' AND Exams.Exam_Name = '$Exam'
            ORDER BY Marks.Std_Id ";
}

$result = $conn -> query($query) -> fetch_all(MYSQLI_ASSOC);
echo json_encode($result);