<?php
header("Content-Type: application/json");

include "../../connect.php";
$Subject = $_POST['Subject'];
$Exam = $_POST['Exam'];
$Grade = $_POST['Grade'];
$Section = $_POST['Section'];
$Marks =(array) json_decode($_POST['Marks']);


$SubQuery = "SELECT Sub_Id FROM Subjects WHERE Sub_Name  = '$Subject'";
$SubRes = $conn->query($SubQuery)->fetch_assoc();
$Sub_Id = $SubRes['Sub_Id'];

$ExamQuery = "SELECT Exam_Id FROM Exams WHERE Exam_Name = '$Exam' ";
$ExamRes = $conn->query($ExamQuery)->fetch_assoc();
$Exam_Id = $ExamRes['Exam_Id'];

$sql = "INSERT INTO Marks (Std_Id, Sub_Id, Exam_Id, Theory_Marks, Practical_Marks) 
        VALUES (?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
            Theory_Marks = VALUES(Theory_Marks),
            Practical_Marks = VALUES(Practical_Marks) ";
$UpdateMarksQuery = $conn -> prepare($sql);
$UpdateMarksQuery ->bind_param("iiiii", $Std_Id, $Sub_Id, $Exam_Id, $Th_Mark , $Pr_Mark);

foreach($Marks as $Std_Id => $Mark){
    $Mark = (array) $Mark;
    $Th_Mark = $Mark['Th'];
    $Pr_Mark = $Mark['Pr'];
    $UpdateMarksQuery -> execute();
    if(!$UpdateMarksQuery){
        echo json_encode(["Error"=>"Update Failed"]);
        exit();
    }
}
$UpdateMarksQuery -> close();
echo json_encode(["Success"=>"Marks updated successfully"]);
$conn -> close();

