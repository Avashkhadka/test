<?php
header('Content-Type: application/json');

include '../../../connect.php';
$Grade = $_POST['Grade'];
$Sec_Name = $_POST['Name'];

//Errors to deal with
//Class not chosen
//Empty Section input
//Duplicate Section input

if ($Grade === "Default"){
    echo json_encode(['ClassError'=>'Select a class']);
    exit();
}
if(trim($Sec_Name," ") == ''){
    echo json_encode(['EmptyInput'=>'Enter a section name']);
    exit();
}
$checkQuery = "SELECT Section FROM Class WHERE Grade = $Grade";
 $result = $conn->query($checkQuery);
 if ($result) {
    // Fetch all rows
    while ($row = $result->fetch_assoc()) {
        // Check if the section already exists
        if (strtolower($row['Section']) == strtolower($Sec_Name)) {
            echo json_encode(['Duplicate' => 'Section already exists']);
            exit();
        }
    }
}

$sql = "INSERT INTO Class (Grade,Section) VALUES ('$Grade','$Sec_Name')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['Class_id' => $conn->insert_id, 'Section' => $Sec_Name]);
} else {
    echo json_encode(['error' => $conn->error]);
}

$conn->close();
?>
