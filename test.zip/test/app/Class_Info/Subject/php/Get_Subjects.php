<?php
header('Content-Type: application/json');

include '../../../connect.php';
$Grade = $_POST['Grade'];
$query = "SELECT Sub_Id, IsOptional, Opt_Group FROM Class_Subjects WHERE Grade = '$Grade'";

$result = $conn->query($query);
$SubjectArray = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $Sub_Id = $row["Sub_Id"];
            $query2 = "SELECT Sub_Name FROM subjects WHERE Sub_Id =$Sub_Id";
            $qresult = $conn->query($query2)->fetch_assoc();
            $Sub_Name = $qresult['Sub_Name'];
            $IsOptional = $row["IsOptional"];
            $Opt_Group = $row["Opt_Group"];
            $Optional = $IsOptional==="0"?"No":"Optional ".$Opt_Group;

            $Subject = ["Sub_Id"=>$Sub_Id, "Name"=>$Sub_Name, "Optional"=>$Optional];
            $SubjectArray [] = $Subject;
        }
        echo json_encode($SubjectArray);
    }else{
        echo json_encode(['error' => 'No Subjects found']);
    }

$conn->close();
