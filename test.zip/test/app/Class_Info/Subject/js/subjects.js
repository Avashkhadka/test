document.addEventListener("DOMContentLoaded", () => {
    const Grade_Select = document.getElementById("Grade");
    const AddSub_Dialog = document.getElementById("AddSub-Dialog");
    const AddSub_Button = document.getElementById("AddSub-Button");
    const Dialog_CloseButton = document.getElementById("Dialog-CloseButton");
    const Dialog_CancelButton = document.getElementById("Dialog-CancelButton");
    const Dialog2_CloseButton = document.getElementById("Dialog2-CloseButton");
    const Dialog2_CancelButton = document.getElementById("Dialog2-CancelButton");
  
    AddSub_Button.addEventListener("click", (e) => {
      e.stopPropagation();
      if (Grade_Select.value === "Default") {
        const Class_Error = document.querySelector("#Class-Error");
        Class_Error.textContent = "Select a class";
        Grade_Select.focus();
        return;
      }
      AddSub_Dialog.showModal();
    });
  
    Dialog2_CloseButton.addEventListener("click", CloseDialog);
    Dialog2_CancelButton.addEventListener("click", CloseDialog);
    Dialog_CloseButton.addEventListener("click", CloseDialog);
    Dialog_CancelButton.addEventListener("click", CloseDialog);
  
    function CloseDialog() {
      OptSub_Group.style.display = "none";
      AddSub_Dialog.close();
      UpdateSub_Form.close();
    }
  
    const IsOptional = document.querySelectorAll('input[name="IsOptional"]');
    const OptSub_Group = document.getElementById("OptSub-Group");
    let IsOptionalValue = "";
  
    IsOptional.forEach((radio) => {
      radio.addEventListener("change", () => {
        if (
          document.querySelector('input[name="IsOptional"]:checked').value === "1"
        ) {
          OptSub_Group.style.display = "block";
          IsOptionalValue = 1;
        } else {
          OptSub_Group.style.display = "none";
          IsOptionalValue = 0;
        }
      });
    });
  
    const Subject_Input = document.getElementById("Sub-input");
    const Opt_Group_Input = document.getElementById("OptSub-Group-Input");
    const Sub_Form = document.getElementById("AddSub-Form");
    const SubTable_Container = document.getElementById("SubjectsTable-Container");
    const UpdateSub_Form = document.getElementById("UpdateSub-Dialog");
  
    Grade_Select.addEventListener("change", () => {
      const Grade_Value = Grade_Select.value;
      SubTable_Container.innerHTML = "";
      if (Grade_Value === "Default") return;
      Create_TableSkeletion();
      getSubject(Grade_Value);
    });
    let clearSubject = true;
    Sub_Form.addEventListener("submit", (e) => {
      e.preventDefault();
      addSubject(Subject_Input.value, IsOptionalValue, Opt_Group_Input.value);
      if (!clearSubject) {
        Subject_Input.value = "";
      }
    });
  
    function Create_TableSkeletion() {
      const Sub_Table = document.createElement("table");
      const Table_Head = document.createElement("thead");
      const Header_Row = document.createElement("tr");
  
      const headers = ["Sub_id", "Subject Name", "Optional"];
      headers.forEach((headerText) => {
        const table_heading = document.createElement("th");
        table_heading.textContent = headerText;
        Header_Row.appendChild(table_heading);
      });
  
      Table_Head.appendChild(Header_Row);
      Sub_Table.appendChild(Table_Head);
  
      const Table_Body = document.createElement("tbody");
  
      Sub_Table.appendChild(Table_Body);
      SubTable_Container.appendChild(Sub_Table);
    }
    let Sub_Id = ""; //declaring outside of any function to make it global
    function addSubjectsToPage(Subject) {
      const Table_Body = document.querySelector("tbody");
      const Subject_Array = Array.isArray(Subject) ? Subject : [Subject];
      Subject_Array.forEach((Sub) => {
        const row = document.createElement("tr");
  
        Object.values(Sub).forEach((Cell_Content) => {
          const cell = document.createElement("td");
          cell.textContent = Cell_Content;
          row.appendChild(cell);
        });
  
        const ButtonCell = document.createElement("td");
  
        const ButtonMenu = document.createElement("div");
        ButtonMenu.className = "Buttons";
  
        const UpdateButton = document.createElement("button");
        UpdateButton.innerHTML = "Update";
        UpdateButton.className = "UpdateBtn";
        UpdateButton.addEventListener("click", function (e) {
          e.stopPropagation();
          const Current_Row = this.closest("tr");
          const Cells = Current_Row.getElementsByTagName("td");
          Sub_Id = Cells[0].textContent;
          const Sub_Name = Cells[1].textContent;
          const Optional = Cells[2].textContent;
          OpenUpdateDialog(Sub_Name, Optional);
        });
  
        const DeleteButton = document.createElement("button");
        DeleteButton.innerHTML = "Delete";
        DeleteButton.className = "DeleteBtn";
        DeleteButton.addEventListener("click", function (e) {
          e.stopPropagation();
          const Confirm = confirm("Do you really want to delete this Subject?");
          if (!Confirm) return;
          const Current_Row = this.closest("tr");
          const Cells = Current_Row.getElementsByTagName("td");
          Sub_Id = Cells[0].textContent;
          deleteSubject(Sub_Id);
        });
  
        ButtonMenu.append(UpdateButton);
        ButtonMenu.append(DeleteButton);
        ButtonCell.append(ButtonMenu);
        hideButtonMenu();
        row.append(ButtonCell);
  
        row.addEventListener("contextmenu", (e) => {
          e.preventDefault();
          hideButtonMenu();
          toggleButtonMenu(ButtonMenu);
        });
  
        Table_Body.append(row);
      });
    }
  
    function getSubject(Grade) {
      const Selected_Grade = new FormData();
      Selected_Grade.append("Grade", Grade);
  
      fetch("Subject/php/Get_Subjects.php", {
        method: "POST",
        body: Selected_Grade,
      })
        .then((response) => response.json())
        .then((Subject) => {
          if (!Subject.error) {
            addSubjectsToPage(Subject);
            hideButtonMenu();
          } else {
            console.error("Error adding subjects:", Subject.error);
          }
        })
        .catch((error) => {
          console.error("Error", error);
        });
    }
  
    function addSubject(Sub_Name, IsOptionalInput, Opt_Group = "0") {
      const Selected_Grade = Grade_Select.value;
      const NewSubject = new FormData();
      NewSubject.append("Name", Sub_Name);
      NewSubject.append("IsOptional", IsOptionalInput);
      NewSubject.append("Opt_Group", Opt_Group);
      NewSubject.append("Grade", Selected_Grade);
  
      fetch("Subject/php/Add_Subjects.php", {
        method: "Post",
        body: NewSubject,
      })
        .then((response) => response.json())
        .then((Subject) => {
          if (Subject.ClassError) {
            const Class_Error = document.querySelector("#Class-Error");
            Class_Error.textContent = Subject.ClassError;
            Grade_Select.focus();
            return;
          }
          if (Subject.EmptyInput) {
            const Sub_Error = document.querySelector("#Sub-Error");
            Sub_Error.textContent = Subject.EmptyInput;
            Subject_Input.focus();
            return;
          }
          if (Subject.Invalid) {
            const Sub_Error = document.querySelector("#Sub-Error");
            Sub_Error.textContent = Subject.Invalid;
            Subject_Input.focus();
            return;
          }
          if (Subject.Duplicate) {
            const Sub_Error = document.querySelector("#Sub-Error");
            Sub_Error.textContent = Subject.Duplicate;
            Subject_Input.focus();
            return;
          }
          if (Subject.RadioEmpty) {
            const IsOpt_Error = document.querySelector("#IsOpt-Error");
            IsOpt_Error.textContent = Subject.RadioEmpty;
            return;
          }
          if (Subject.EmptyOptGroup) {
            const OptGroup_Error = document.querySelector("#OptGroup-Error");
            OptGroup_Error.textContent = Subject.EmptyOptGroup;
            Opt_Group_Input.focus();
            clearSubject = false;
            return;
          }
  
          addSubjectsToPage(Subject);
          hideButtonMenu();
        })
        .catch((error) => {
          console.error("Error", error);
        });
    }
  
    const UpdatedSubject_Input = document.getElementById("UpdatedSub-input");
    const UpdatedIsOptional = document.querySelectorAll(
      'input[name="UpdatedIsOptional"]'
    );
    const IsOptionalYes = document.getElementById("IsOptionalYes");
    const IsOptionalNo = document.getElementById("IsOptionalNo");
    const UpdatedOptSub_Group = document.getElementById("UpdatedOptSub-Group");
    const UpdatedOptSub_Group_Input = document.getElementById(
      "UpdatedOptSub-Group-Input"
    );
  
    let UpdatedIsOptionalValue = ""; //declaring outside of any function to make it global
  
    UpdatedIsOptional.forEach((radio) => {
      radio.addEventListener("change", () => {
        if (
          document.querySelector('input[name="UpdatedIsOptional"]:checked')
            .value === "1"
        ) {
          UpdatedOptSub_Group.style.display = "block";
          UpdatedIsOptionalValue = 1;
          UpdatedOptSub_Group_Input.value = "";
        } else {
          UpdatedOptSub_Group.style.display = "none";
          UpdatedIsOptionalValue = 0;
          UpdatedOptSub_Group_Input.value = "0";
        }
      });
    });
  
    UpdateSub_Form.addEventListener("submit", (e) => {
      e.preventDefault();
      updateSubject(
        Sub_Id,
        UpdatedIsOptionalValue,
        UpdatedOptSub_Group_Input.value
      );
    });
  
    function OpenUpdateDialog(Sub_Name, Optional) {
      UpdateSub_Form.showModal();
  
      UpdatedSubject_Input.value = Sub_Name;
      if (Optional === "No") {
        IsOptionalNo.checked = true;
        UpdatedOptSub_Group.style.display = "none";
        UpdatedOptSub_Group_Input.value = "0";
        UpdatedIsOptionalValue = "0";
      } else {
        IsOptionalYes.checked = true;
        UpdatedOptSub_Group.style.display = "block";
        UpdatedOptSub_Group_Input.value = Optional.replace(/[^0-9]/g, "");
        UpdatedIsOptionalValue = "1";
      }
    }
  
    function updateSubject(Sub_Id, UpdatedIsOptional, UpdatedOpt_Group = "0") {
      const Selected_Grade = Grade_Select.value;
      const Updated_Subject = new FormData();
      Updated_Subject.append("Grade", Selected_Grade);
      Updated_Subject.append("Sub_Id", Sub_Id);
      Updated_Subject.append("IsOptional", UpdatedIsOptional);
      Updated_Subject.append("Opt_Group", UpdatedOpt_Group);
  
      fetch("Subject/php/Update_Subjects.php", {
        method: "POST",
        body: Updated_Subject,
      })
        .then((response) => response.json())
        .then((Update) => {
          if (Update.EmptyOptGroup) {
            const UpdatedOptGroup_Error = document.querySelector(
              "#UpdatedOptGroup-Error"
            );
            UpdatedOptGroup_Error.textContent = Update.EmptyOptGroup;
            UpdatedOptSub_Group_Input.focus();
          }
          const Table = document.querySelector("table");
          const Row = Table.getElementsByTagName("tr");
          for (let i = 1; i < Row.length; i++) {
            // Start from 1 to skip the header row
            const cells = Row[i].getElementsByTagName("td");
  
            if (cells[0].textContent === Update.Sub_Id) {
              cells[2].textContent = Update.Optional;
              break;
            }
          }
        })
        .catch((error) => {
          console.error("Error", error);
        });
    }
  
    function deleteSubject(Sub_id) {
      const Selected_Grade = Grade_Select.value;
      const Delete_Subject = new FormData();
      Delete_Subject.append("Grade", Selected_Grade);
      Delete_Subject.append("Sub_Id", Sub_id);
  
      fetch("Subject/php/Delete_Subjects.php", {
        method: "POST",
        body: Delete_Subject,
      })
        .then((response) => response.json())
        .then((Sub_TO_Delete) => {
          const Table = document.querySelector("table");
          const Row = Table.getElementsByTagName("tr");
          for (let i = 1; i < Row.length; i++) {
            // Start from 1 to skip the header row
            const cells = Row[i].getElementsByTagName("td");
  
            if (cells[0].textContent === Sub_TO_Delete.Sub_Id) {
              Table.deleteRow(i);
              break;
            }
          }
        });
    }
    document.addEventListener("click", () => {
      hideButtonMenu();
    });
    function toggleButtonMenu(Menu) {
      Menu.style.display = Menu.style.display === "block" ? "none" : "block";
    }
    function hideButtonMenu() {
      document.querySelectorAll(".Buttons").forEach((menu) => {
        menu.style.display = "none";
      });
    }
  });
  