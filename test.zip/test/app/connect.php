<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $database = "student";

    $conn = new mysqli($server,$user,$password,$database);

    if(!$conn){
        die("Connection failed: " . $conn->connect_error);
    }
    
?>