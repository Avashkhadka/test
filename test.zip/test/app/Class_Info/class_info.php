<?php 
session_start();
if(!isset($_SESSION["user"])){
header("Location:/test/prototype/login.php");
}
?>

<?php

require_once "../../login\connection.php";
        if(!empty($_SESSION["id"])){
            $id=$_SESSION["id"];
            $result=mysqli_query($conn,"SELECT * From login WHERE id=$id");
            $row=mysqli_fetch_assoc($result);
            
        }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Document</title>

    <link rel="stylesheet" href="../../css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
      integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>

  <body>
  <div class="container">
      <div class="nav-res">
        <div class="head">
          <div class="cont-ham-box">
            <div class="cont-hamburger">
              <i onclick="ramesh()" class="fa-solid fa-bars"></i>
            </div>
            
          </div>
        </div>
      <div class="nav">
        <div class="user">
          <div class="profile"></div>
          <p class="username">
            <?php echo $row['username'];?>
          </p>
        </div>

        <div class="header">header</div>

        <div class="nav-link">
          <div class="items nav-link-item">
            <div class="nav-logo">
              <i class="fa-solid fa-gauge-high fa-lg"></i>
            </div>
            <a href="../../index.php">Dashboard</a>
          </div>
          <div class="items nav-link-item activepage">
            <div class="nav-logo">
              <i class="fa-solid fa-book fa-lg"></i>
            </div>
            <a href="../Class_Info/class_info.php">Class info</a>
          </div>

          <div class="items nav-link-item">
            <div class="nav-logo">
              <i class="fa-solid fa-pencil fa-lg"></i>
            </div>
            <a href="../Insert_Marks/Insert_Marks.php">Insert Marks</a>
          </div>

          <div class="items nav-link-item">
            <div class="nav-logo">
              <i class="fa-solid fa-clipboard-user fa-lg"></i>
            </div>
            <a href="../Insert_Records/Insert_Record.php">Add student record</a>
          </div>

          <!-- *end nav link  -->
        </div>

        <div class="items logout">
          <div class="nav-logo">
            <i class="fa-solid fa-right-from-bracket fa-lg"></i>
          </div>
          <a href="../../login/logout.php">Logout</a>

          <!-- *end logout -->
        </div>
        <!-- *end nav  -->
      </div>
      </div>
      <!-- *content -->
      <div class="content-box">
      <div class="cont-head">
          <div class="cont-head-box">
            <div class="title">
              Student Management
              </div>
            
          </div>
        </div>

        <h1>Edit Class Information</h1>
        <div class="Class">
          <h3 class="Class-heading">Class</h3>
          <select class="Class-dropdown" id="Grade">
            <option value="Default">Choose the class</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
          </select>
          <span class="Error" id="Class-Error"></span>
        </div>

        <div class="Section">
          <h3 class="Section-heading">Sections</h3>
          <input
            type="text"
            class="Section-input"
            id="Section-input"
            placeholder="Enter the Section"
          /><br />
          <span class="Error" id="Section-Error"></span>
          <br />
          <input
            type="button"
            class="AddSec-Button"
            id="AddSec-Button"
            value="Add Section"
          />
          <ul id="Section-List"></ul>
          <br />
        </div>
        <div class="Subject">
          <h3 class="Subject-heading">Subjects</h3>
          <input
            type="button"
            class="AddSub-Button"
            id="AddSub-Button"
            value="Add Subject"
          />
        </div>

        <dialog class="AddSub-Dialog" id="AddSub-Dialog">
          <form class="AddSub-Form" id="AddSub-Form" method="dialog">
            <h5 class="AddSub-Form-Header">Add Subject</h5>
            <input
              type="reset"
              value="&times"
              class="Dialog-CloseButton"
              id="Dialog-CloseButton"
            />

            <br />
            <input
              type="text"
              class="Sub-input"
              id="Sub-input"
              placeholder="Enter the subject name"
              autocomplete="off"
            /><br />
            <span class="Error" id="Sub-Error"></span>
            <br />
            Optional subject <br />
            <input type="radio" name="IsOptional" value="1" />Yes
            <input type="radio" name="IsOptional" value="0" />NO<br />
            <span class="Error" id="IsOpt-Error"></span>
            <br />
            <div class="OptSub-Group" id="OptSub-Group">
              Optional group<br />
              <input
                type="text"
                class="OptSub-Group-Input"
                id="OptSub-Group-Input"
                placeholder="1 or 2 or....."
                autocomplete="off"
              /><br />
              <span class="Error" id="OptGroup-Error"></span>
            </div>
            <br />
            <input
              type="Submit"
              class="Dialog-SaveButton"
              id="Dialog-SaveButton"
              value="Save"
            />
            <input
              type="reset"
              class="Dialog-CancelButton"
              id="Dialog-CancelButton"
              value="Cancel"
            />
          </form>
        </dialog>

        <dialog class="UpdateSub-Dialog" id="UpdateSub-Dialog">
          <form class="UpdateSub-Form" id="UpdateSub-Form" method="dialog">
            <h5 class="UpdateSub-Form-Header">Update Subject</h5>
            <input
              type="button"
              value="&times"
              class="Dialog2-CloseButton"
              id="Dialog2-CloseButton"
            />
            <br />
            <input
              type="text"
              class="UpdatedSub-input"
              id="UpdatedSub-input"
              readonly
            /><br />
            Optional subject <br />
            <input
              type="radio"
              id="IsOptionalYes"
              name="UpdatedIsOptional"
              value="1"
              required
            />Yes
            <input
              type="radio"
              id="IsOptionalNo"
              name="UpdatedIsOptional"
              value="0"
            />NO <br />
            <div class="UpdatedOptSub-Group" id="UpdatedOptSub-Group">
              Optional group<br />
              <input
                type="text"
                class="UpdatedOptSub-Group-Input"
                id="UpdatedOptSub-Group-Input"
                placeholder="1 or 2 or....."
                autocomplete="off"
              /><br />
              <span class="Error" id="UpdatedOptGroup-Error"></span>
            </div>
            <br />
            <input
              type="Submit"
              class="Dialog2-SaveButton"
              id="Dialog2-SaveButton"
              value="Save"
            />
            <input
              type="button"
              class="Dialog2-CancelButton"
              id="Dialog2-CancelButton"
              value="Cancel"
            />
          </form>
        </dialog>
        <div id="SubjectsTable-Container"></div>
        <script src="../../js/hover.js"></script>
        <script src="Section/js/sections.js"></script>
        <script src="Subject/js/subjects.js"></script>
      </div>
    </div>
  </body>
</html>
