<?php
header('Content-Type: application/json');

include '../../../connect.php';

$Class_id = $_POST['Id'];
$Section_Name = $_POST['Name'];

//Errors to deal with
//Empty Section input
//Duplicate Section input

$sql = "UPDATE Class SET Section='$Section_Name' WHERE Class_id=$Class_id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => $conn->error]);
}

$conn->close();
?>
