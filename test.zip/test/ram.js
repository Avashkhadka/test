let print=document.querySelector(".pnt");{
    
}