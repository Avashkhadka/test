<?php
header("Content-Type: application/json");

include "../../connect.php";

$Grade = $_POST['Grade'];
$Section = $_POST['Section'];

if($Grade === "Default"){
    echo json_encode(["Error"=>"Default class"]);
    exit();
}

$query1 = "SELECT Section FROM Class WHERE Grade = '$Grade'";
$query2 = "SELECT Class_Subjects.Opt_Group, Subjects.Sub_Name, Subjects.Sub_Id
            FROM Class_Subjects
            JOIN Subjects
            ON Subjects.Sub_Id = Class_Subjects.Sub_Id
            WHERE Class_Subjects.Grade = '$Grade' AND Class_Subjects.IsOptional = '1'
            ORDER BY Class_Subjects.Opt_Group";

$Result1 = $conn -> query($query1) ->fetch_all(MYSQLI_NUM);
$Result2 = $conn -> query($query2) -> fetch_all(MYSQLI_ASSOC);


$groupedSubjects = [];

foreach ($Result2 as $row) {
    $optGroup = $row['Opt_Group'];
    $subName = $row['Sub_Name'];
    $subId = $row['Sub_Id'];

    // Initialize the group if it doesn't exist
    if (!isset($groupedSubjects[$optGroup])) {
        $groupedSubjects[$optGroup] = [];
    }

    // Add the subject details to the group
    $groupedSubjects[$optGroup][] = [
        'Sub_Name' => $subName,
        'Sub_Id' => $subId
    ];
}


$finalResult = ["Sections"=>$Result1,"Subjects"=>$groupedSubjects];

if($Result1 || $Result2){
    echo json_encode($finalResult);
}else{
    echo json_encode(["Error"=>"Error fetching data"]);
}
$conn -> close();

// 0
// : 
// {"1": [{Sub_Name: "Economics", Sub_Id: "6"},{Sub_Name: "Opt Math", Sub_Id: "5"}]}
// 2
// : 
// {Opt_Group: "2", Sub_Name: "Account", Sub_Id: "8"}
// 3
// : 
// {Opt_Group: "2", Sub_Name: "Computer", Sub_Id: "7"}
