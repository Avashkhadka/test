<?php
header('Content-Type: application/json');

include '../../../connect.php';

$Class_Id = $_POST['Id'];

$sql = "DELETE FROM Class WHERE Class_Id=$Class_Id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => $conn->error]);
}

$conn->close();
?>
