document.addEventListener("DOMContentLoaded", () => {
  const Grade_Select = document.getElementById("Grade");
  const Section_input = document.getElementById("Section-input");
  const AddSec_Button = document.getElementById("AddSec-Button");
  const Section_List = document.getElementById("Section-List");
  const Section_Name_Error = document.getElementById("subjectNameError");

  Grade_Select.addEventListener("change", () => {
    Section_List.innerHTML = "";
    var Selected_GradeValue = Grade_Select.value;
    if (Selected_GradeValue === "Default") return;
    getSection(Grade_Select);
  });

  AddSec_Button.addEventListener("click", (e) => {
    e.stopPropagation();
    Selected_Grade = Grade_Select.value;
    addSection(Section_input.value);
    Section_input.value = "";
  });

  document.addEventListener("click", (e) => {
    hideButtonMenu();
    RemoveErrorMsg();
  });

  function addSectionToPage(Class_id, Section) {
    const li = document.createElement("li");
    li.dataset.id = Class_id;

    const SectionName = document.createElement("span");
    SectionName.className = "Section-name";
    SectionName.textContent = Section;
    li.appendChild(SectionName);

    const ButtonMenu = document.createElement("div");
    ButtonMenu.className = "Button-menu";

    const UpdateButton = document.createElement("button");
    UpdateButton.innerHTML = "Update";
    UpdateButton.className = "UpdateBtn";
    UpdateButton.addEventListener("click", (e) => {
      e.stopPropagation();
      const Updated_Section_Input = prompt("Update the Section ");
      if (Updated_Section_Input) {
        updateSection(Class_id, Updated_Section_Input);
      }
    });

    const DeleteButton = document.createElement("button");
    DeleteButton.innerHTML = "Delete";
    DeleteButton.className = "DeleteBtn";
    DeleteButton.addEventListener("click", (e) => {
      e.stopPropagation();
      const Confirm = confirm("Do you really want to delete this section?");
      if (!Confirm) return;
      deleteSection(Class_id);
    });

    ButtonMenu.append(UpdateButton);
    ButtonMenu.append(DeleteButton);
    li.append(ButtonMenu);

    li.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      hideButtonMenu();
      toggleButtonMenu(ButtonMenu);
    });
    Section_List.append(li);
  }

  function getSection(Grade_Select) {
    const Selected_Grade = new FormData();
    Selected_Grade.append("Grade", Grade_Select.value);
    fetch("Section/php/Get_Sections.php", {
      method: "POST",
      body: Selected_Grade,
    })
      .then((response) => response.json())
      .then((data) => {
        data.forEach((Class) => {
          addSectionToPage(Class.Class_id, Class.Section);
          hideButtonMenu();
        });
      })
      .catch((error) => console.log("error fetching data", error));
  }

  function addSection(Section_Name) {
    const NewSection = new FormData();
    Selected_Grade = document.getElementById("Grade").value;
    //show error ; choose class or enter a section
    NewSection.append("Grade", Selected_Grade);
    NewSection.append("Name", Section_Name);

    fetch("Section/php/Add_Sections.php", {
      method: "POST",
      body: NewSection,
    })
      .then((response) => response.json())
      .then((Class) => {
        if (Class.ClassError) {
          const Class_Error = document.querySelector("#Class-Error");
          Class_Error.textContent = Class.ClassError;
          Grade_Select.focus();
          return;
        } else if (Class.EmptyInput) {
          const Section_Error = document.querySelector("#Section-Error");
          Section_Error.textContent = Class.EmptyInput;
          Section_input.focus();
          return;
        } else if (Class.Duplicate) {
          const Section_Error = document.querySelector("#Section-Error");
          Section_Error.textContent = Class.Duplicate;
          Section_input.focus();
          return;
        }

        if (!Class.error) {
          addSectionToPage(Class.Class_id, Class.Section);
          hideButtonMenu();
        }
      });
  }

  function updateSection(Class_id, NewSection_Name) {
    const Updated_Section = new FormData();
    Updated_Section.append("Id", Class_id);
    Updated_Section.append("Name", NewSection_Name);

    fetch("Section/php/Update_Sections.php", {
      method: "POST",
      body: Updated_Section,
    })
      .then((response) => response.json())
      .then((Update) => {
        if (Update.success) {
          const SectionToUpdate = document.querySelector(
            `li[data-id="${Class_id}"]`
          );
          if (SectionToUpdate) {
            SectionToUpdate.querySelector(".Section-name").textContent =
              NewSection_Name;
          }
        } else {
          console.error("Error updating item:", Update.error);
        }
      });
    hideButtonMenu();
  }

  function deleteSection(Class_id) {
    const Deleted_Section = new FormData();
    Deleted_Section.append("Id", Class_id);

    fetch("Section/php/Delete_Sections.php", {
      method: "POST",
      body: Deleted_Section,
    })
      .then((response) => response.json())
      .then((Delete) => {
        if (Delete.success) {
          const SectionToDelete = document.querySelector(
            `li[data-id="${Class_id}"]`
          );
          if (SectionToDelete) {
            SectionToDelete.remove();
          }
        } else {
          console.error("Error deleting item:", Delete.error);
        }
      });
  }

  function toggleButtonMenu(Menu) {
    Menu.style.display = Menu.style.display === "block" ? "none" : "block";
  }

  function hideButtonMenu() {
    document.querySelectorAll(".Button-menu").forEach((menu) => {
      menu.style.display = "none";
    });
  }
  function RemoveErrorMsg() {
    const Error = document.querySelectorAll(".Error");
    Error.forEach((error) => {
      error.textContent = "";
    });
  }
});
