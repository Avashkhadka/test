<?php
header("Content-Type: application/json");

include "../../connect.php";

$Grade = $_POST['Grade'];
$Section = $_POST['Section'];

$query = "SELECT Max(Students.Roll_no) as MaxRollNo
            FROM Students
            JOIN Class
            ON Class.Class_Id = Students.Class_Id
            WHERE Class.Grade = '$Grade' AND Class.Section = '$Section'";
$result = $conn -> query($query) ->fetch_assoc();

$Roll_No = (int)$result['MaxRollNo'] + 1;

echo json_encode(["Roll_No"=>$Roll_No]);

$conn -> close();