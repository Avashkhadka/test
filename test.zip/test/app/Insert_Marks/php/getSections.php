<?php
header("Content-Type: application/json");

include '../../connect.php';

$Grade = $_POST['Grade'];

if($Grade === "Default"){
    echo json_encode(["ClassError"=>"Choose a class"]);
    exit();
}

$Sql = "SELECT Section FROM Class WHERE Grade = $Grade";
$result = $conn->query($Sql);

$Section= [];
if($result->num_rows > 0){
    while($row =$result->fetch_assoc() ){
        $sec['Name'] = $row['Section'];
        $Section[] = $sec; 
    }
    echo json_encode($Section);
}else{
    echo json_encode(["Error"=>"No Sections Found"]);
}

$conn->close();

