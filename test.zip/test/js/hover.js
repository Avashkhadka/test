document.addEventListener('DOMContentLoaded',()=>{
const nav=document.querySelector(".cont-ham-box");
const navchild=document.querySelector(".nav");

nav.addEventListener("mouseenter",()=>{
navchild.style.display="block";
});


navchild.addEventListener("mouseleave",()=>{
    setTimeout(()=>{
if(!nav.matches(":hover") &&!navchild.matches(":hover")){
    navchild.style.display="none";
}
},100);
});



});