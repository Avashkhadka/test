<?php
session_start();
if(isset($_SESSION["user"])){
header("Location:../index.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="login-css/style.css">
    <title>login</title>
</head>
<body>
    <form action="login.php" method="post">


<div class="container">
<?php
require_once "connection.php";
if(isset($_POST["login"])){
    $email=$_POST["email"];
    $password=$_POST["password"];

    $sql="SELECT * From login WHERE email='$email'";
    $res=mysqli_query($conn,$sql);
    $user=mysqli_fetch_array($res,MYSQLI_ASSOC);

    if($user){
        if(password_verify($password,$user["password"])){
            session_start();
            $_SESSION["user"]="yes";
            $_SESSION["id"]=$user["id"];
        header("location: ../index.php");
        die();
        }
        else{
            echo"<div class='alert alert-danger'>password  doesnt match</div>";
        }
    }else{
    echo"<div class='alert alert-danger'>email doesnt mathc</div>";
    }
}



?>
    <div class="form_group">
        <div class="header text-center">
            <div class="fs-1">
                login
            </div>
        </div>
    </div>

    <div class="form-group">
        <input type="text" placeholder="enter email" class="form-control"  name="email"><br>
    </div>

    <div class="form-group">
        <input type="password" placeholder="enter password" class="form-control" name="password"><br>
    </div>

    <div class="form-group">
        <input type="submit"  class="btn btn-primary" value="login" name="login">
        <a href="signup.php"><input type="button"  class="btn btn-danger" value="signup"></a><br>
    </div>

</div>

</form>


</body>
</html>