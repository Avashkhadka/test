<?php
header('Content-Type: application/json');

include '../../../connect.php';

$Grade = $_POST['Grade'];
$Sub_Id= $_POST['Sub_Id'];
$IsOptional = $_POST['IsOptional'];
$Opt_Group = $_POST['Opt_Group'];

// Errors to handle:
// 4. When IsOptional raido is yes, Opt_Group is not provided

if($IsOptional == "1" && !$Opt_Group){
    echo json_encode(['EmptyOptGroup'=>'Enter the optional group']);
    exit();
}

function executeQuery($conn, $query) {
    $result = $conn->query($query);
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    return $result;
}

$query = "SELECT Sub_Name FROM Subjects WHERE Sub_Id = '$Sub_Id'";
$result = executeQuery($conn, $query);
$Sub_Name = $result->fetch_assoc();


$query = "UPDATE Class_Subjects SET IsOptional=$IsOptional, Opt_Group='$Opt_Group' WHERE Grade = $Grade AND Sub_Id = $Sub_Id  ";

if(executeQuery($conn, $query)){
    echo json_encode(["Sub_Id"=>$Sub_Id, "Optional"=>$IsOptional==="0"?"No":"Optional ".$Opt_Group]);
}else{
    echo json_encode(["Error"=>$conn->error]);
}