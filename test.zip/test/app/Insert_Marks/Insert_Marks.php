<?php 
session_start();
if(!isset($_SESSION["user"])){
header("Location:/test/prototype/login.php");
}
?>

<?php

require_once "../../login\connection.php";
        if(!empty($_SESSION["id"])){
            $id=$_SESSION["id"];
            $result=mysqli_query($conn,"SELECT * From login WHERE id=$id");
            $row=mysqli_fetch_assoc($result);
            
        }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Document</title>

    <link rel="stylesheet" href="../../css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
      integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>

  <body>
  <div class="container">
      <div class="nav-res">
        <div class="head">
          <div class="cont-ham-box">
            <div class="cont-hamburger">
              <i onclick="ramesh()" class="fa-solid fa-bars"></i>
            </div>
            
          </div>
        </div>
      <div class="nav">
        <div class="user">
          <div class="profile"></div>
          <p class="username">
            <?php echo $row['username'];?>
          </p>
        </div>

        <div class="header">header</div>

        <div class="nav-link">
          <div class="items nav-link-item">
            <div class="nav-logo">
              <i class="fa-solid fa-gauge-high fa-lg"></i>
            </div>
            <a href="../../index.php">Dashboard</a>
          </div>
          <div class="items nav-link-item">
            <div class="nav-logo">
              <i class="fa-solid fa-book fa-lg"></i>
            </div>
            <a href="../Class_Info/class_info.php">Class info</a>
          </div>

          <div class="items nav-link-item activepage">
            <div class="nav-logo">
              <i class="fa-solid fa-pencil fa-lg"></i>
            </div>
            <a href="../Insert_Marks/Insert_Marks.php">Insert Marks</a>
          </div>

          <div class="items nav-link-item">
            <div class="nav-logo">
              <i class="fa-solid fa-clipboard-user fa-lg"></i>
            </div>
            <a href="../Insert_Records/Insert_Record.php">Add student record</a>
          </div>

          <!-- *end nav link  -->
        </div>

        <div class="items logout">
          <div class="nav-logo">
            <i class="fa-solid fa-right-from-bracket fa-lg"></i>
          </div>
          <a href="../../login/logout.php">Logout</a>

          <!-- *end logout -->
        </div>
        <!-- *end nav  -->
      </div>
      </div>
      <!-- *content -->
      <div class="content-box">
      <div class="cont-head">
          <div class="cont-head-box">
            <div class="title">
              Student Management
              </div>
            
          </div>
        </div>

 
  
        <h1>Insert Students Marks</h1>
        <table id="ClassTable">
          <tbody>
            <tr>
              <td>
                Class
                <select class="Class-dropdown" id="Grade">
                  <option value="Default">Choose the class</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                </select>
              </td>
              <td>
                Section
                <select name="Section" id="Section" class="Section-dropdown">
                  <option value="Default">All</option>
                </select>
              </td>
              <td>
                Subjects
                <select name="Subjects" id="Subject" class="Subject-dropdown">
                  <option value="Default" class="Default">
                    Choose a Subject
                  </option>
                </select>
              </td>
            </tr>
            <tr>
              <td>
                <span class="Error" id="ClassError"></span>
              </td>
              <td>
                <span class="Error" id="SectionError"></span>
              </td>
              <td>
                <span class="Error" id="SubjectError"></span>
              </td>
            </tr>
          </tbody>
        </table>
        Exam:
        <input
          type="text"
          name="ExamName"
          id="ExamName"
          class="ExamName"
          placeholder="E.g. First Term"
          list="ExamList"
        /><br />
        <datalist id="ExamList"></datalist>
        <span class="Error" id="ExamError"></span>
        <div class="MarksInsert" id="MarksInsert"></div>
        <span class="Error" id="MarksError"></span>
        <span class="Success" id="InsertSuccess"></span>
        <div class="Buttons" id="Buttons">
          <input
            type="button"
            class="Button hidden"
            id="SaveBtn"
            value="Save"
          />
          <input
            type="button"
            class="Button hidden"
            id="ClearBtn"
            value="Clear"
          />
          <input
            type="button"
            class="Button hidden"
            id="GenerateBtn"
            value="Generate Result"
          />
        </div>
        <script src="js/Marks.js"></script>
        <script src="../../js/hover.js"></script>
      </div>
    </div>
  </body>
</html>
