<?php 
header("Content-Type: application/json");

include "../../../connect.php";

$Grade = $_POST['Grade'];
$Sub_Id = $_POST['Sub_Id'];

$sql = "DELETE FROM Class_Subjects WHERE Grade = '$Grade' AND Sub_Id = '$Sub_Id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['Sub_Id' => $Sub_Id]);
} else {
    echo json_encode(['error' => $conn->error]);
}

$conn->close();