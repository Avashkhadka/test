<?php
header('Content-Type: application/json');

include '../../../connect.php';
if (isset($_POST['Grade'])) {
    $grade = $_POST['Grade'];
    $sql = "SELECT  Class_id , Section FROM class WHERE  Grade = $grade";
    $result = $conn->query($sql);
    $Sections = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $Sections[] = $row;
        }
    }
    echo json_encode($Sections);
}else{
    echo json_encode(['error' => 'Grade not provided']);
    http_response_code(400); // Bad Request
}
$conn->close();
?>
