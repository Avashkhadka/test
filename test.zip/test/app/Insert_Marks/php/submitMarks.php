<?php
header("Content-Type: application/json");
include "../../connect.php";
$Subject = $_POST['Subject'];
$Exam = $_POST['Exam'];
$Grade = $_POST['Grade'];
$Section = $_POST['Section'];
$Marks =(array) json_decode($_POST['Marks']);

//handling empty exam name
if (!trim($Exam," ")){
    echo json_encode(["ExamError"=>"Enter the exam name"]);
    exit();
}
//handling default subject
if($Subject ==="Default"){
    echo json_encode(["SubjectError"=>"Choose a subject"]);
    exit();
}
//handling empty , negative, large marks
foreach($Marks as $Id => $mark){
    $mark = (array) $mark;
    if(!$mark["Th"]){
        echo json_encode(["MarksError" => "$Id-Th:Enter the marks"]);
        exit();
    }
    if(!$mark["Pr"]){
        echo json_encode(["MarksError" => "$Id-Pr:Enter the marks"]);
        exit();
    }
    if($mark["Th"] < 0){
        echo json_encode(["MarksError" => "$Id-Th:Marks can't be negative"]);
        exit();
    }
    if($mark["Pr"] < 0){
        echo json_encode(["MarksError" => "$Id-Pr:Marks can't be negative"]);
        exit();
    }
    if($mark["Th"] > 75){
        echo json_encode(["MarksError" => "$Id-Th:Thoery marks can't be greater than 75"]);
        exit();
    }
    if($mark["Th"] + $mark["Pr"] >  100){
        echo json_encode(["MarksError" => "$Id-Pr:Total marks can't be greater than 100"]);
        exit();
    }
}
//fetching the subject id for corresponding subject
$SubQuery = "SELECT Sub_Id FROM Subjects WHERE Sub_Name  = '$Subject'";
$SubRes = executeQuery($conn,$SubQuery)->fetch_assoc();
$Sub_Id = $SubRes['Sub_Id'];

//adding exam to the db if it doesn't already exists, and taking the id if it already does
$SendExam = false;
$query = "SELECT Exam_Id FROM Exams WHERE Exam_Name = '$Exam' ";
$result = executeQuery($conn,$query);
if ($result->num_rows == 0) {
    $SendExam = true;
    $InsertQuery = "INSERT INTO Exams (Exam_Name) VALUES('$Exam')";
    $res = executeQuery($conn,$InsertQuery);
    $Exam_Id = $conn -> insert_id;
}else{
    $res = $result->fetch_assoc();
    $Exam_Id = $res['Exam_Id'];
}  

//fetching the class_id ,needed in case of a specific section selected
$SecQuery = "SELECT Class_Id FROM Class WHERE Grade  = '$Grade' AND Section = '$Section'";
$SecRes = executeQuery($conn,$SecQuery)->fetch_assoc();
if($SecRes){
    $Class_Id = $SecRes['Class_Id'];
}



if($Section === "Default"){
    $checkMarks = "SELECT DISTINCT Class.Grade, Marks.Sub_Id, Marks.Exam_Id
                    FROM ((Marks
                    JOIN Students ON Marks.Std_Id = Students.Std_Id)
                    JOIN Class ON Students.Class_Id = Class.Class_Id)";
    $queryResult = executeQuery($conn,$checkMarks);
    $Combination= [];
    if($queryResult->num_rows > 0){
        while($data =$queryResult->fetch_assoc() ){
            $Combination[] = $data; 
        }
    }

    foreach($Combination as $Array){
        if($Array['Grade'] == $Grade && $Array['Sub_Id'] == $Sub_Id && $Array['Exam_Id'] == $Exam_Id){
            echo json_encode(["Update"=>"Marks already exists. Do you want to update the marks?"]);
            exit();
        }

    }
}else{
    $checkMarks = "SELECT DISTINCT Students.Class_Id, Marks.Sub_Id, Marks.Exam_Id
                    FROM Marks
                    JOIN Students ON Marks.Std_Id = Students.Std_Id";
    $queryResult = executeQuery($conn,$checkMarks);
    $Combination= [];
    if($queryResult->num_rows > 0){
        while($data =$queryResult->fetch_assoc() ){
            $Combination[] = $data; 
        }
    }

    foreach($Combination as $Array){
        if($Array['Class_Id'] == $Class_Id && $Array['Sub_Id'] == $Sub_Id && $Array['Exam_Id'] == $Exam_Id){
            echo json_encode(["Update"=>"Marks already exists. Do you want to update the marks?"]);
            exit();
        }

    }
}

$InsertMarksQuery = $conn -> prepare( "INSERT INTO Marks (Std_Id, Sub_Id, Exam_Id, Theory_Marks, Practical_Marks) VALUES (?,?,?,?,?)");
$InsertMarksQuery ->bind_param("iiiii",$Std_Id, $Sub_Id, $Exam_Id, $Th_Mark , $Pr_Mark);

foreach($Marks as $Std_Id => $Mark){
    $Mark = (array) $Mark;
    $Th_Mark = $Mark['Th'];
    $Pr_Mark = $Mark['Pr'];
    $InsertMarksQuery -> execute();
}

if($SendExam){ 
    echo json_encode(["Exam"=>$Exam,"Success"=>"Records added successfully"]);
}else{
    echo json_encode(["Success"=>"Records added successfully"]);
}
$InsertMarksQuery -> close();
$conn -> close();

function executeQuery($conn, $query) {
    $result = $conn->query($query);
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    return $result;
}
