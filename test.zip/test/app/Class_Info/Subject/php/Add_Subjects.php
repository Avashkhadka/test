<?php
header('Content-Type: application/json');

include '../../../connect.php';
$Sub_Name = $_POST['Name'];
$IsOptional = $_POST['IsOptional'];
$Opt_Group = $_POST['Opt_Group'];
$Grade = $_POST['Grade'];


// Errors to handle:
// 1. Class is not chosen
// 2. Subject name is empty (or just spaces)
// 3. IsOptional radio box is not checked
// 4. When IsOptional raido is yes, Opt_Group is not provided
// 5. Subject already exists 

function executeQuery($conn, $query) {
    $result = $conn->query($query);
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    return $result;
}

if ($Grade === "Default"){
    echo json_encode(['ClassError'=>'Select a class']);
    exit();
}

if(!$Sub_Name){
    echo json_encode(['EmptyInput'=>'Enter a subject name']);
    exit();
}
$Sub_Name = preg_replace( '/[0-9]/i', '', $Sub_Name);
if(!trim($Sub_Name," ")){
    echo json_encode(['Invalid'=>'Invalid Subject Name']);
    exit();
}
if($IsOptional === "" ){
    echo json_encode(['RadioEmpty'=>'Select an option']);
    exit();
}
if($IsOptional == "1" && !$Opt_Group){
    echo json_encode(['EmptyOptGroup'=>'Enter the optional group']);
    exit();
}



$query = "SELECT Sub_id FROM Subjects WHERE Sub_name = '$Sub_Name'";
$resultId = executeQuery($conn, $query);


if ($resultId->num_rows > 0) {
    $Subject = $resultId->fetch_assoc();
    $Sub_Id = $Subject['Sub_id'];
    $checkQuery = "SELECT Sub_Id FROM Class_Subjects WHERE Grade = $Grade";
    $result = $conn->query($checkQuery);
    if ($result) {
    // Fetch all rows
    while ($row = $result->fetch_assoc()) {
        // Check if the section already exists
        if ($row['Sub_Id'] == $Sub_Id) {
            echo json_encode(['Duplicate' => 'Subject already exists']);
            exit();
        }
    }
    }
} else {
    $query = "INSERT INTO Subjects (Sub_Name) VALUES ('$Sub_Name')";
    executeQuery($conn, $query);
    $Sub_Id = $conn->insert_id;
}

$query = "INSERT INTO Class_Subjects (Grade, Sub_id, IsOptional, Opt_Group) VALUES ($Grade, $Sub_Id, $IsOptional, '$Opt_Group')";

if(executeQuery($conn, $query)){
    echo json_encode(["Sub_Id"=>$Sub_Id, "Name"=>$Sub_Name, "Optional"=>$IsOptional==="0"?"No":"Optional ".$Opt_Group]);
}else{
    echo json_encode(["Error"=>$conn->error]);
}

$conn->close();
?>

