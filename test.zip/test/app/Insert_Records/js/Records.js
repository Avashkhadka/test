document.addEventListener("DOMContentLoaded", () => {
  const Name_Input = document.querySelector(".Student-Name");
  /**@type {HTMLSelectElement} */
  const Grade_Select = document.querySelector(".Class-dropdown");
  const Section_Select = document.querySelector(".Section-dropdown");
  const Roll_No_Input = document.querySelector("#Roll-No");
  const Optional_Subjects = document.querySelector(".Optional-Subjects");
  const Submit = document.querySelector("#Submit");

  const Name_Error = document.getElementById("Name-Error");
  const Class_Error = document.getElementById("Class-Error");
  const Section_Error = document.getElementById("Section-Error");
  const Roll_No_Error = document.getElementById("Roll_No-Error");
  const Insert_Error = document.getElementById("Insert-Error");
  const Insert_Success = document.getElementById("Insert-Success");

  document.addEventListener("click", () => {
    RemoveErrorMsg();
  });

  Grade_Select.addEventListener("change", () => {
    removeOptions(Section_Select);
    Roll_No_Input.value = "";
    Optional_Subjects.innerHTML = "";
    getSecAndSub();
  });

  Section_Select.addEventListener("change", () => {
    getRollNo();
  });

  Submit.addEventListener("click", () => {
    submitMarks();
  });

  function getSecAndSub() {
    const Selected_Grade = Grade_Select.value;
    const Selected_Section = Section_Select.value;
    const Grade = new FormData();
    Grade.append("Grade", Selected_Grade);
    Grade.append("Section", Selected_Section);

    fetch("php/getSecSub.php", {
      method: "POST",
      body: Grade,
    })
      .then((response) => response.json())
      .then((Grade) => {
        if (!Grade.Error) {
          addSections(Grade.Sections);
          if (Grade.Subjects) {
            addSubjects(Grade.Subjects);
          }
        }
      })
      .catch((error) => console.error(error));
  }
  function addSections(Sections) {
    Sections.forEach((Sec) => {
      const Option = document.createElement("option");
      Option.value = Sec;
      Option.textContent = Sec;

      Section_Select.append(Option);
    });
  }

  function addSubjects(Subjects) {
    Optional_Subjects.innerHTML = `Choose the optional subjects:<br><br>`;
    Object.keys(Subjects).forEach((Group) => {
      const div = document.createElement("div");
      div.innerHTML = `Optional ${Group}: `;

      const Select = document.createElement("select");
      Select.className = `Optional`;
      Select.id = `Optional-${Group}: `;

      Subjects[Group].forEach((Subject) => {
        const Option = document.createElement("option");
        Option.value = Subject.Sub_Id;
        Option.textContent = Subject.Sub_Name;

        Select.append(Option);
      });
      div.append(Select);
      Optional_Subjects.append(div);
      const line_break = document.createElement("br");
      Optional_Subjects.append(line_break);
    });
  }

  function submitMarks() {
    const Std_Name = Name_Input.value;
    const Grade = Grade_Select.value;
    const Roll_No = Roll_No_Input.value;
    const Section = Section_Select.value;
    const Sub_Ids = Array.from(document.querySelectorAll(".Optional")).map(
      (Sub) => Sub.options[Sub.selectedIndex].value
    );
    const Records = new FormData();

    Records.append("Name", Std_Name);
    Records.append("Grade", Grade);
    Records.append("Roll_No", Roll_No);
    Records.append("Section", Section);
    Records.append("Sub_Ids", JSON.stringify(Sub_Ids));

    fetch("php/submitRecords.php", {
      method: "POST",
      body: Records,
    })
      .then((response) => response.json())
      .then((Message) => {
        if (Message.NameError) {
          Name_Error.textContent = Message.NameError;
          return;
        }
        if (Message.GradeError) {
          Class_Error.textContent = Message.GradeError;
          return;
        }
        if (Message.SectionError) {
          Section_Error.textContent = Message.SectionError;
          return;
        }
        if (Message.Roll_NoError) {
          Roll_No_Error.textContent = Message.Roll_NoError;
          return;
        }
        if (Message.InsertError) {
          Insert_Error.textContent = Message.InsertError;
          return;
        }
        Insert_Success.textContent = Message.InsertSucess;
        Name_Input.value = "";
        getRollNo();
      })
      .catch((Error) => {
        Error;
      });
  }
  function getRollNo() {
    const Selected_Grade = Grade_Select.value;
    const Selected_Section = Section_Select.value;
    const Grade = new FormData();
    Grade.append("Grade", Selected_Grade);
    Grade.append("Section", Selected_Section);

    fetch("php/getRollNo.php", {
      method: "POST",
      body: Grade,
    })
      .then((response) => response.json())
      .then((Class) => {
        Roll_No_Input.value = Class.Roll_No;
      });
  }
  function removeOptions(RemoveID) {
    const Options = Array.from(RemoveID.children);
    const ArrayLength = Options.length;
    for (i = 1; i < ArrayLength; i++) {
      Options[i].remove();
    }
  }
  function RemoveErrorMsg() {
    const Error = document.querySelectorAll(".Error");
    Error.forEach((error) => {
      error.textContent = "";
    });
  }
});
