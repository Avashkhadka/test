<?php
header("Content-Type: application/json");

include "../../connect.php";

$Std_Name = $_POST['Name'];
$Grade = $_POST['Grade'];
$Roll_No = $_POST['Roll_No'];
$Section = $_POST['Section'];
$Sub_Ids = json_decode($_POST['Sub_Ids']);




if(!$Std_Name){
    echo json_encode(["NameError"=>"Enter a Name"]);
    exit();
}
$Std_Name = preg_replace( '/[^a-zA-Z ]/', '', $Std_Name);
if(!trim($Std_Name," ")){
    echo json_encode(["NameError"=>"Invalid Name"]);
    exit();
}
if($Grade === "Default"){
    echo json_encode(["GradeError"=>"Choose a Class"]);
    exit();
}
if($Section === "Default"){
    echo json_encode(["SectionError"=>"Choose a Section"]);
    exit();
}
if(!$Roll_No){
    echo json_encode(["Roll_NoError"=>"Enter a Roll No."]);
    exit();
}

$RollCheckQuery = "SELECT Class.Grade, Class.Section,Class.Class_Id
            FROM Class
            JOIN Students
            ON Students.Class_Id = Class.Class_Id  
            WHERE Students.Roll_no = '$Roll_No' AND Class.Grade = '$Grade' AND Class.Section = '$Section' ";
$Duplicate = $conn -> query($RollCheckQuery);
if($Duplicate->num_rows > 0){
    $Student = $Duplicate->fetch_assoc();
    $Error_Grade = $Student['Grade'];
    $Error_Section = $Student['Section'];
    echo json_encode(["Roll_NoError"=>"Roll No. already exists in Class $Error_Grade Section $Error_Section"]);
    exit();
}

$id = $conn->query("SELECT Class_Id FROM Class WHERE Grade='$Grade' AND Section = '$Section'") ->fetch_assoc();
$Class_Id = $id['Class_Id'];

$insertQuery1 = "INSERT INTO Students (Std_Name, Roll_No, Class_Id) VALUES ('$Std_Name','$Roll_No','$Class_Id') ";
$result1 = $conn ->query($insertQuery1);
$Std_Id = $conn -> insert_id;

if(!$result1){
    echo json_encode(["InsertError" => "Error inserting records"]);
    exit();
}

foreach($Sub_Ids as $Sub_Id){
    $insertQuery2 = "INSERT INTO Students_Subjects (Std_Id, Sub_Id) VALUES ('$Std_Id','$Sub_Id') ";
    $result2 = $conn ->query($insertQuery2);
    if(!$result2){
        echo json_encode(["InsertError"=>"Error inserting records"]);
        exit();
    }
}

echo json_encode(["InsertSucess"=>"Records Added Successfully"]);



$conn -> close();