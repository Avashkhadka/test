<?php
header("Content-Type: application/json");

include "../../connect.php";

$Grade = $_POST['Grade'];
$Section = $_POST['Section'];
$Subject = $_POST['Subject'];




if($Section === "Default"){
        $query = "SELECT Students.Std_Id, Students.Roll_no, Students.Std_Name, Class.Section
        FROM Students 
        JOIN Class 
        ON Class.Class_Id = Students.Class_Id 
        WHERE Class.Grade = '$Grade'
        ORDER BY Students.Std_Id ";
}else{
        $query = "SELECT Students.Std_Id, Students.Roll_no, Students.Std_Name
        FROM Students 
        JOIN Class 
        ON Class.Class_Id = Students.Class_Id 
        WHERE Class.Grade = '$Grade' AND Class.Section = '$Section'
        ORDER BY Students.Std_Id ";
    }

    


$result = $conn -> query($query);
$Students= [];
if($result->num_rows > 0){
    while($row =$result->fetch_assoc() ){
        $Students[] = $row; 
    }
    echo json_encode($Students);
}else{
    echo json_encode(["Error"=>"No Students Found"]);
}