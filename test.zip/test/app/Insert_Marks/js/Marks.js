let eventListenerAttached = false;
document.addEventListener("DOMContentLoaded", () => {
  /** @type {HTMLSelectElement} */
  const Grade_Select = document.getElementById("Grade");
  const Section_Select = document.getElementById("Section");
  const Subject_Select = document.getElementById("Subject");
  const Marks_Insert = document.getElementById("MarksInsert");
  const Exam_Name = document.getElementById("ExamName");
  const Exam_List = document.getElementById("ExamList");

  document.addEventListener("click", clearMessage);
  getExamList();
  Exam_Name.addEventListener("change", (event) => {
    const Exam = event.target.value;
    if (Exam.trim()) {
      getMarks(Exam);
    }
  });

  Grade_Select.addEventListener("change", (e) => {
    e.stopPropagation();
    removeOptions(Section_Select);
    removeOptions(Subject_Select);
    if (Grade_Select.value === "Default") hideButtons();
    getSection();
    getSubject();
    getStudents();
  });

  Section_Select.addEventListener("change", (e) => {
    e.stopPropagation();
    check("Section");
    toggleMarksInput();
  });

  Subject_Select.addEventListener("change", (e) => {
    e.stopPropagation();
    check();
    toggleMarksInput();
  });

  var PreviousStatus = "Default";
  function check(Call) {
    const Subjects = document.getElementById("Subject").options;
    const CurrentStatus = Subjects[Subject_Select.selectedIndex].className;
    if (CurrentStatus === "Optional") {
      getOptStudents();
    } else if (
      (PreviousStatus === "Default" && CurrentStatus === "Not-Optional") ||
      (PreviousStatus === "Optional" && CurrentStatus === "Not-Optional") ||
      CurrentStatus === "Default" ||
      (CurrentStatus === "Not-Optional" && Call === "Section")
    ) {
      getStudents();
    } else {
      getMarks();
    }
    PreviousStatus = CurrentStatus;
  }
  function getMarks() {
    const Exam = Exam_Name.value;
    const Grade = Grade_Select.value;
    const Section = Section_Select.value;
    const Subject = Subject_Select.value;

    const Info = new FormData();
    Info.append("Exam", Exam);
    Info.append("Grade", Grade);
    Info.append("Section", Section);
    Info.append("Subject", Subject);

    fetch("php/getMarks.php", {
      method: "POST",
      body: Info,
    })
      .then((response) => response.json())
      .then((Marks) => {
        if (!Marks.Error) {
          populateMarks(Marks);
        }
      })
      .catch((Error) => console.error(Error));
  }

  function populateMarks(Marks) {
    Marks = Array.isArray(Marks) ? Marks : [Marks];

    const Theory_MarkField = document.querySelectorAll('[id$="-Th"]');
    Theory_MarkField.forEach((input) => (input.value = ""));
    const Practical_MarkField = document.querySelectorAll('[id$="-Pr"]');
    Practical_MarkField.forEach((input) => (input.value = ""));
    if (Marks.length > 0) {
      Marks.forEach((mark) => {
        const Theory_MarkField = document.getElementById(`${mark.Std_Id}-Th`);
        Theory_MarkField.value = mark.Theory_Marks;
        const Practical_MarkField = document.getElementById(
          `${mark.Std_Id}-Pr`
        );
        Practical_MarkField.value = mark.Practical_Marks;
      });
    }
  }

  function getExamList() {
    fetch("php/getExamList.php")
      .then((response) => response.json())
      .then((Exams) => {
        addExamOption(Exams);
      })
      .catch((error) => console.error(error));
  }

  function addExamOption(Exams) {
    Exams = Array.isArray(Exams) ? Exams : [Exams];
    Exams.forEach((exam) => {
      const Option = document.createElement("Option");
      Option.value = exam;
      Exam_List.append(Option);
    });
  }
  function getSection() {
    const Grade = Grade_Select.value;
    const Current_Grade = new FormData();
    Current_Grade.append("Grade", Grade);

    fetch("php/getSections.php", {
      method: "POST",
      body: Current_Grade,
    })
      .then((response) => response.json())
      .then((Sections) => {
        if (Sections.ClassError) {
          console.log("Default Class");
          return;
        }
        if (!Sections.Error) {
          addOptions(Section_Select, Sections);
        }
      })
      .catch((error) => {
        console.error("Error", error);
      });
  }
  function getSubject() {
    const Grade = Grade_Select.value;
    const Current_Grade = new FormData();
    Current_Grade.append("Grade", Grade);

    fetch("php/getSubjects.php", {
      method: "POST",
      body: Current_Grade,
    })
      .then((response) => response.json())
      .then((Subjects) => {
        if (Subjects.ClassError) {
          console.log("Default Class");
          return;
        }
        if (!Subjects.Error) {
          addOptions(Subject_Select, Subjects);
        }
      })
      .catch((error) => {
        console.error("Error", error);
      });
  }
  function getStudents() {
    const Grade = Grade_Select.value;
    const Section = Section_Select.value;
    const Subject = Subject_Select.value;
    const Current_Grade = new FormData();
    Current_Grade.append("Grade", Grade);
    Current_Grade.append("Section", Section);
    Current_Grade.append("Subject", Subject);

    fetch("php/getStudents.php", {
      method: "POST",
      body: Current_Grade,
    })
      .then((response) => response.json())
      .then((Students) => {
        if (Students.Error) {
          Marks_Insert.innerHTML = "";
          return;
        }
        displayStudents(Students, Section, Subject_Select.value);
      })
      .catch((error) => {
        console.error("Error", error);
      });
  }

  function getOptStudents() {
    const Grade = Grade_Select.value;
    const Section = Section_Select.value;
    const Subject = Subject_Select.value;
    const Current_Grade = new FormData();
    Current_Grade.append("Grade", Grade);
    Current_Grade.append("Section", Section);
    Current_Grade.append("Subject", Subject);

    fetch("php/getOptStudents.php", {
      method: "POST",
      body: Current_Grade,
    })
      .then((response) => response.json())
      .then((Students) => {
        if (Students.Error) {
          Marks_Insert.innerHTML = "";
          return;
        }
        displayStudents(Students, Section, Subject_Select.value);
      })
      .catch((error) => {
        console.error("Error", error);
      });
  }

  function addOptions(SelectID, OptionItems) {
    OptionItems.forEach((Item) => {
      const Option = document.createElement("option");
      Option.value = Item.Name;
      Option.textContent = Item.Name;

      if (Item.IsOptional === "1") {
        Option.className = "Optional";
      } else if (Item.IsOptional === "0") {
        Option.className = "Not-Optional";
      }

      SelectID.append(Option);
    });
  }
  function removeOptions(RemoveID) {
    const Options = Array.from(RemoveID.children);
    const ArrayLength = Options.length;
    for (i = 1; i < ArrayLength; i++) {
      Options[i].remove();
    }
  }

  function displayStudents(Students, Section, Subject = "Default") {
    Marks_Insert.innerHTML = "";
    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const tbody = document.createElement("tbody");
    const Theory_Class =
      Subject === "Default" ? "Theory-Marks hidden" : "Theory-Marks";
    const Practical_Class =
      Subject === "Default" ? "Practical-Marks hidden" : "Practical-Marks";
    const headerRow = document.createElement("tr");
    if (Section === "Default") {
      headerRow.innerHTML = `
            <th>Section</th>
            <th>Roll No</th>
            <th>Student Name</th>
            <th class = "${Theory_Class}" >Theory Marks</th>
            <th class = "${Practical_Class}" >Practical Marks</th>
        `;
    } else {
      headerRow.innerHTML = `
            <th>Roll No</th>
            <th>Student Name</th>
            <th class = "${Theory_Class}" >Theory Marks</th>
            <th class = "${Practical_Class}" >Practical Marks</th>
        `;
    }

    thead.appendChild(headerRow);

    Students.forEach((student) => {
      const row = document.createElement("tr");
      if (Section === "Default") {
        row.innerHTML = `
                <td>${student.Section}</td>
                <td>${student.Roll_no}</td>
                <td>${student.Std_Name}</td>
                <td><input type="number" name="marks"  id = "${student.Std_Id}-Th"  class = "${Theory_Class}" min="0" max = "100"></td>
                <td><input type="number" name="marks"  id = "${student.Std_Id}-Pr"  class = "${Practical_Class}" min="0" max = "100"></td>
            `;
      } else {
        row.innerHTML = `
                <td>${student.Roll_no}</td>
                <td>${student.Std_Name}</td>
                <td><input type="number" name="marks" id = "${student.Std_Id}-Th" class = "${Theory_Class}" min="0" max = "100"></td>
                <td><input type="number" name="marks" id = "${student.Std_Id}-Pr" class = "${Practical_Class}" min="0" max = "100"></td>
            `;
      }
      tbody.appendChild(row);
    });

    table.appendChild(thead);
    table.appendChild(tbody);
    Marks_Insert.appendChild(table);
    addInputEventListener();
    getMarks();
  }

  function addInputEventListener() {
    const theoryInputs = document.querySelectorAll("input.Theory-Marks");
    const practicalInputs = document.querySelectorAll("input.Practical-Marks");
    function navigateInputs(event) {
      const key = event.key;
      const currentIndex = Array.from(theoryInputs).indexOf(event.target);
      const practicalIndex = Array.from(practicalInputs).indexOf(event.target);

      if (key === "ArrowRight" || key === "ArrowLeft") {
        event.preventDefault();
        if (key === "ArrowRight") {
          if (currentIndex !== -1) {
            practicalInputs[currentIndex].focus();
          } else if (
            practicalIndex !== -1 &&
            practicalIndex < theoryInputs.length - 1
          ) {
            theoryInputs[practicalIndex + 1].focus();
          }
        }
        if (key === "ArrowLeft") {
          if (practicalIndex !== -1) {
            theoryInputs[practicalIndex].focus();
          } else if (currentIndex !== -1 && currentIndex > 0) {
            practicalInputs[currentIndex - 1].focus();
          }
        }
      } else if (key === "ArrowDown" || key === "Enter" || key === "ArrowUp") {
        event.preventDefault();
        if (key === "ArrowDown" || key === "Enter") {
          if (currentIndex !== -1 && currentIndex < theoryInputs.length - 1) {
            theoryInputs[currentIndex + 1].focus();
          } else if (
            practicalIndex !== -1 &&
            practicalIndex < practicalInputs.length - 1
          ) {
            practicalInputs[practicalIndex + 1].focus();
          }
        }
        if (key === "ArrowUp") {
          if (currentIndex !== -1 && currentIndex > 0) {
            theoryInputs[currentIndex - 1].focus();
          } else if (practicalIndex !== -1 && practicalIndex > 0) {
            practicalInputs[practicalIndex - 1].focus();
          }
        }
      }
    }

    theoryInputs.forEach((input) =>
      input.addEventListener("keydown", navigateInputs)
    );
    practicalInputs.forEach((input) =>
      input.addEventListener("keydown", navigateInputs)
    );
  }

  function toggleMarksInput() {
    const Subject = Subject_Select.value;
    const Marks = document.querySelectorAll(".Marks");
    if (Subject === "Default") {
      Marks.forEach((field) => {
        field.classList.add("hidden");
      });
      hideButtons();
    } else {
      Marks.forEach((field) => {
        field.classList.remove("hidden");
      });
      showButtons();
    }
  }

  function showButtons() {
    const Save_Button = document.getElementById("SaveBtn");
    const Generate_Result_Button = document.getElementById("GenerateBtn");
    const Clear_Button = document.getElementById("ClearBtn");
    Save_Button.classList.remove("hidden");
    Generate_Result_Button.classList.remove("hidden");
    Clear_Button.classList.remove("hidden");
    attachButtonEventListeners();
  }
  function attachButtonEventListeners() {
    if (!eventListenerAttached) {
      const Save_Button = document.getElementById("SaveBtn");
      const Generate_Result_Button = document.getElementById("GenerateBtn");
      const Clear_Button = document.getElementById("ClearBtn");
      Save_Button.addEventListener("click", (e) => {
        e.stopPropagation();
        submitMarks();
      });

      Generate_Result_Button.addEventListener("click", (e) => {
        e.stopPropagation();
      });

      Clear_Button.addEventListener("click", clearField);

      eventListenerAttached = true;
    }
  }
  function hideButtons() {
    const Save_Button = document.getElementById("SaveBtn");
    const Generate_Result_Button = document.getElementById("GenerateBtn");
    Save_Button.classList.add("hidden");
    Generate_Result_Button.classList.add("hidden");
  }

  function clearField() {
    const Theory_MarkField = document.querySelectorAll('[id$="-Th"]');
    Theory_MarkField.forEach((input) => (input.value = ""));
    const Practical_MarkField = document.querySelectorAll('[id$="-Pr"]');
    Practical_MarkField.forEach((input) => (input.value = ""));
  }

  function submitMarks() {
    const Theory_Marks_Input = document.querySelectorAll("input.Theory-Marks");
    const Practical_Marks_Input = document.querySelectorAll(
      "input.Practical-Marks"
    );
    const Exam = Exam_Name.value;
    const Subject = Subject_Select.value;

    const Data = new FormData();
    Data.append("Exam", Exam);
    Data.append("Subject", Subject);
    Data.append("Grade", Grade_Select.value);
    Data.append("Section", Section_Select.value);

    const Theory_Marks = [];
    const Practical_Marks = [];
    Theory_Marks_Input.forEach((mark) => {
      Theory_Marks[mark.id] = mark.value;
    });

    Practical_Marks_Input.forEach((mark) => {
      Practical_Marks[mark.id] = mark.value;
    });
    // ["1000":{"Th":"63","Pr":"23"},"1001":{"Th":"34","Pr":"20"}]
    const Marks = mergeMarks(Theory_Marks, Practical_Marks);

    Data.append("Marks", JSON.stringify(Marks));

    fetch("php/submitMarks.php", {
      method: "POST",
      body: Data,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.ExamError) {
          const Exam_Error = document.getElementById("ExamError");
          Exam_Error.textContent = data.ExamError;
        }
        if (data.MarksError) {
          const [Std_Id, Message] = data.MarksError.split(":");
          const Field = document.getElementById(`${Std_Id}`);
          Field.focus();
          const ErrorSpan = document.getElementById("MarksError");
          ErrorSpan.textContent = Message;
        }
        if (data.Update) {
          const isUpdate = confirm(data.Update);
          if (isUpdate) {
            UpdateMarks(Data);
          }
        }
        if (data.Success) {
          const Insert_Success = document.querySelector(".Success");
          Insert_Success.textContent = data.Success;
        }
        if (data.Exam) {
          addExamOption(Exam);
        }
      })
      .catch((Error) => console.error(Error));
  }

  function UpdateMarks(Data) {
    fetch("php/updateMarks.php", {
      method: "POST",
      body: Data,
    })
      .then((response) => response.json())
      .then((Message) => {
        if (Message.Error) {
          const Error = document.getElementById("MarksError");
          Error.textContent = Message.Error;
        }
        if (Message.Success) {
          const Success = document.getElementById("InsertSuccess");
          Success.textContent = Message.Success;
        }
      })
      .catch((error) => console.error(error));
  }
  function clearMessage() {
    const Success = document.querySelector(".Success");
    const Error = document.querySelectorAll(".Error");
    Error.forEach((span) => {
      span.textContent = "";
    });
    Success.textContent = "";
  }
  function mergeMarks(theory, practical) {
    const mergedMarks = {};

    // Process theory marks
    for (let key in theory) {
      if (theory.hasOwnProperty(key)) {
        const [stdId, type] = key.split("-");
        if (!mergedMarks[stdId]) {
          mergedMarks[stdId] = {};
        }
        mergedMarks[stdId][type] = theory[key];
      }
    }

    // Process practical marks
    for (let key in practical) {
      if (practical.hasOwnProperty(key)) {
        const [stdId, type] = key.split("-");
        if (!mergedMarks[stdId]) {
          mergedMarks[stdId] = {};
        }
        mergedMarks[stdId][type] = practical[key];
      }
    }

    return mergedMarks;
  }
});
