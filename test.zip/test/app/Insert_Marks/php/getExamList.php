<?php
header("Content-Type: application/json");

include "../../connect.php";

$query = "SELECT Exam_Name FROM Exams";
$result = $conn -> query($query) -> fetch_all(MYSQLI_NUM);

if($result){
    echo json_encode($result);
}