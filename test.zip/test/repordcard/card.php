<?php 
session_start();
if(!isset($_SESSION["user"])){
header("Location:../login/login.php");
}
?>
<?php

require_once "..\login\connection.php";
        if(!empty($_SESSION["id"])){
            $id=$_SESSION["id"];
            $result=mysqli_query($conn,"SELECT * From login WHERE id=$id");
            $row=mysqli_fetch_assoc($result);
            
        }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Document</title>

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
      integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../css/reportcard.css" />
    <style>
      @media print {
        .noPrint {
          display: none;
        }
        body {
          height: 842px;
          width: 595px;
        }
      }
    </style>
  </head>

  <body>
    <div class="container">
      <div class="nav-res noPrint">
        <div class="head">
          <div class="cont-ham-box">
            <div class="cont-hamburger">
              <i onclick="ramesh()" class="fa-solid fa-bars"></i>
            </div>
          </div>
        </div>
        <div class="nav">
          <div class="user">
            <div class="profile"></div>
            <p class="username">
              <?php echo $row['username'];?>
            </p>
          </div>

          <div class="header">header</div>

          <div class="nav-link">
            <div class="items nav-link-item activepage">
              <div class="nav-logo">
                <i class="fa-solid fa-gauge-high fa-lg"></i>
              </div>
              <a href="index.php">Dashboard</a>
            </div>
            <div class="items nav-link-item">
              <div class="nav-logo">
                <i class="fa-solid fa-book fa-lg"></i>
              </div>
              <a href="app/Class_Info/class_info.php">Class info</a>
            </div>

            <div class="items nav-link-item">
              <div class="nav-logo">
                <i class="fa-solid fa-pencil fa-lg"></i>
              </div>
              <a href="app/Insert_Marks/Insert_Marks.php">Insert Marks</a>
            </div>

            <div class="items nav-link-item">
              <div class="nav-logo">
                <i class="fa-solid fa-clipboard-user fa-lg"></i>
              </div>
              <a href="app/Insert_Records/Insert_Record.php"
                >Add student record</a
              >
            </div>

            <!-- *end nav link  -->
          </div>

          <div class="items logout">
            <div class="nav-logo">
              <i class="fa-solid fa-right-from-bracket fa-lg"></i>
            </div>
            <a href="../login/logout.php">Logout</a>

            <!-- *end logout -->
          </div>
        </div>
        <!-- *end nav  -->
      </div>

      <div class="content-box">
        <div class="cont-head noPrint">
          <div class="cont-head-box">
            <div class="title">Student Management</div>
          </div>
        </div>

        <div class="studentcard">
          <div class="slogan">
            <p>honesty</p>
            <p>wisdom</p>
            <p>Victory</p>
          </div>
        
            <div class="clzname">
                <h1>Cardinal International Boarding High School</h1>
              </div>
          <div class="info">
          <div class="logo">
            
            </div>s
              <div class="clzname">
                <h1>(CIBHS)</h1>
              </div>
              <div class="clzname">
                <h4>Satikhel, Pharping, Kathmandu</h4>
              </div>
              <div class="clzname">
                <h4>ESTD:1995</h4>
              </div>
          </div>



          <div class="noPrint">
            <button class="print" onclick="window.print()">Print</button>
          </div>
        </div>

        <script src="ram.js"></script>
        <script src="../js/hover.js"></script>
        <!-- *content box end here -->
      </div>
    </div>
  </body>
</html>
