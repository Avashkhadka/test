<?php
header("Content-Type: application/json");

include '../../connect.php';

$Grade = $_POST['Grade'];

if($Grade === "Default"){
    echo json_encode(["ClassError"=>"Choose a class"]);
    exit();
}

$Sql = "SELECT Subjects.Sub_Name, Class_Subjects.IsOptional
        FROM Subjects
        JOIN Class_Subjects
        ON Class_Subjects.Sub_Id = Subjects.Sub_Id
        WHERE Grade ='$Grade'";
$result = $conn->query($Sql);
if($result->num_rows > 0){
    while($res =$result->fetch_assoc() ){
        $Sub['Name'] = $res['Sub_Name'];
        $Sub['IsOptional'] = $res['IsOptional'];
        $Subjects[] = $Sub;
    }
    echo json_encode($Subjects);
}else{
    echo json_encode(["Error"=>"No Subjects Found"]);
}



    
$conn -> close();





