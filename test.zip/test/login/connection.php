<?php
$conn=mysqli_connect("localhost","root","","student");
if(!$conn){
    die("database not connecter".mysqli_connect_error());
}

?>