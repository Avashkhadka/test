    <?php
    session_start();
    if(isset($_SESSION["user"])){
    header("Location:../index.php");
    }
    ?>


    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>registration form</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel="stylesheet" href="login-css/style.css">
    </head>
    <body>
    <div class="container">
    <form action="signup.php" method="post">

    <?php

    include "connection.php";
    if(isset($_POST["submit"]))
    {
    $username=$_POST["username"];
    $email=$_POST["email"];
    $password=$_POST["password"];
    $c_passoword=$_POST["confirm-password"];

    $passwordhash=password_hash($password,PASSWORD_DEFAULT);
    $error=array();
    if(empty($username) OR empty($email) OR empty($password) OR empty($c_passoword)){
        array_push($error,"all fields are required");
    }
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        array_push($error,"email is not valid");
    }
    if(strlen($password)<8)
    {
        array_push($error,"password must be greater than 8 character");
    }
    if($password!==$c_passoword){
        array_push($error,"password doesnt match");
    }


    $sql1="SELECT * FROM login where username='$username'";
    $result1=mysqli_query($conn,$sql1);
    $rowcount1=mysqli_num_rows($result1);
    if($rowcount1>0){
        array_push($error,"username already exists");
    }

    $sql="SELECT * FROM login where email='$email'";
    $result=mysqli_query($conn,$sql);
    $rowcount=mysqli_num_rows($result);
    if($rowcount>0){
        array_push($error,"email already exists");
    }

    if(count($error)>0){
        foreach($error as $error){
            echo"<div class='alert alert-danger'>$error</div>";
        
        }
    }else{

        $sql="INSERT INTO login (username,email,password) values (?,?,?) ";
        $stmt= mysqli_stmt_init($conn);
        $preparestmt= mysqli_stmt_prepare($stmt,$sql);
    if($preparestmt){
        mysqli_stmt_bind_param($stmt,"sss",$username,$email,$passwordhash);
        mysqli_stmt_execute($stmt);
        echo"<div class='alert alert-success'>sign up sucessifully redirecting in login page</div>";
        echo"<script>
    setTimeout(() => {
        window.location.href='login.php';
    }, 3000);
        </script>";
        }else{
        die("something went wrong"); 
        }

    }
    }


    ?>


<div class="form_group">
        <div class="header text-center">
            <div class="fs-1">
                signup
            </div>
        </div>
    </div>

        <div class="form-group">
                <label for="username"></label>
                <input type="text" name="username" class="form-control" placeholder="username"><br>
        </div>
            
        <div class="form-group">
            
                <input type="text" name="email" class="form-control" placeholder="email"><br>
        </div>
        <div class="form-group">
                
                <input type="password" name="password" class="form-control" placeholder="password"><br>
        </div>
        <div class="form-group">
            
                <input type="password" name="confirm-password" class="form-control" placeholder="confirm-password"><br>
        </div>
        <div class="form-group">
            <input type="submit" value="Sign up" class="btn btn-primary" name="submit">
            <a href="login.php"><input type="button"  class="btn btn-danger" value="login"></a><br>
        </div>
        </form>

    </div>



    </body>
    </html>