<?php
header("Content-Type: application/json");

include "../../connect.php";

$Grade = $_POST['Grade'];
$Section = $_POST['Section'];
$Subject = $_POST['Subject'];

if($Subject === "Default") {
    echo json_encode(["Error"=>"Default Subject"]);
    exit();
}
$OptCheckQuery = "SELECT Class_Subjects.IsOptional,Subjects.Sub_Id
    FROM Class_Subjects
    JOIN Subjects
    ON Subjects.Sub_Id = Class_Subjects.Sub_Id
    WHERE Subjects.Sub_Name = '$Subject' AND Class_Subjects.Grade = '$Grade'";
$res = $conn -> query($OptCheckQuery) -> fetch_assoc();
$IsOptional = $res['IsOptional'];
$Sub_Id = $res['Sub_Id'];

if($IsOptional == "0"){
    echo json_encode(["Error"=>"Compulsary subject"]);
    exit();
}
if($Section === "Default"){
    $query = "SELECT Students_Subjects.Std_Id, Students.Roll_no, Students.Std_Name, Class.Section
    FROM ((Students
    JOIN Class ON Class.Class_Id = Students.Class_Id )
    JOIN Students_Subjects ON Students_Subjects.Std_Id = Students.Std_Id)
    WHERE Class.Grade = '$Grade' AND Students_Subjects.Sub_Id = '$Sub_Id'  ";
}else{
    $query = "SELECT Students_Subjects.Std_Id, Students.Roll_no, Students.Std_Name
    FROM ((Students
    JOIN Class ON Class.Class_Id = Students.Class_Id)
    JOIN Students_Subjects ON Students_Subjects.Std_Id = Students.Std_Id)
    WHERE Class.Grade = '$Grade' AND Class.Section = '$Section' AND Students_Subjects.Sub_Id = '$Sub_Id' ";
}

$result = $conn -> query($query);
$Sections= [];
if($result->num_rows > 0){
    while($sec =$result->fetch_assoc() ){
        $Sections[] = $sec; 
    }
    echo json_encode($Sections);
}else{
    echo json_encode(["Error"=>"No Students Found"]);
}